<?php
		if(isset($this->data['color'][1]))
		{
?>
			<?php echo $this->data['mainCSSClass']; ?> a,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-button,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-booking-summary>li>h5,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-package-list>li>.cbs-package-price
			{
				color:#<?php echo $this->data['color'][1]; ?>;
			}

			<?php echo $this->data['mainCSSClass']; ?> .cbs-button:hover,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-state-selected>.cbs-button,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-state-selected>.cbs-button-box>.cbs-button,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-vehicle-list>li:hover,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-vehicle-list>li.cbs-state-selected,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-main-list>li.cbs-main-list-item>div.cbs-main-list-item-section-header>.cbs-main-list-item-section-header-step,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar-header .cbs-calendar-header-arrow-left:hover,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar-header .cbs-calendar-header-arrow-right:hover,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar .cbs-calendar-subheader .cbs-calendar-subheader-day-number.cbs-state-selected,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar .cbs-calendar-data a:hover,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar .cbs-calendar-data .cbs-state-selected>a,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-to-tab.ui-tabs .ui-tabs-nav li.ui-tabs-active a,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-to-tab.ui-tabs .ui-tabs-nav li.ui-state-hover a
			{
				background-color:#<?php echo $this->data['color'][1]; ?>;
			}

			<?php echo $this->data['mainCSSClass']; ?> .cbs-button,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-vehicle-list>li:hover,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-vehicle-list>li.cbs-state-selected,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar-header .cbs-calendar-header-arrow-left:hover,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar-header .cbs-calendar-header-arrow-right:hover,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar .cbs-calendar-subheader .cbs-calendar-subheader-day-number.cbs-state-selected,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar .cbs-calendar-data a:hover,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar .cbs-calendar-data .cbs-state-selected>a
			{
				border-color:#<?php echo $this->data['color'][1]; ?>;
			}
<?php
		}
		if(isset($this->data['color'][2]))
		{	
?>
			<?php echo $this->data['mainCSSClass']; ?> .cbs-button:hover,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-state-selected>.cbs-button,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-state-selected>.cbs-button-box>.cbs-button,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-main-list>li.cbs-main-list-item>div.cbs-main-list-item-section-header>.cbs-main-list-item-section-header-step,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-vehicle-list>li:hover,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-vehicle-list>li:hover .cbs-vehicle-icon,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-vehicle-list>li.cbs-state-selected,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-vehicle-list>li.cbs-state-selected .cbs-vehicle-icon,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar-header .cbs-calendar-header-arrow-left:hover,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar-header .cbs-calendar-header-arrow-right:hover,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar .cbs-calendar-subheader .cbs-calendar-subheader-day-number.cbs-state-selected,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar .cbs-calendar-data a:hover,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar .cbs-calendar-data .cbs-state-selected>a,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-to-tab.ui-tabs .ui-tabs-nav li.ui-tabs-active a,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-to-tab.ui-tabs .ui-tabs-nav li.ui-state-hover a
			{
				color:#<?php echo $this->data['color'][2]; ?>;
			}	
<?php
		}
		if(isset($this->data['color'][3]))
		{	
?>
			<?php echo $this->data['mainCSSClass']; ?> .cbs-service-list>li>.cbs-service-name,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-package-list>li>.cbs-package-name,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar-header .cbs-calendar-header-caption,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar .cbs-calendar-subheader .cbs-calendar-subheader-day-number,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-main-list>li.cbs-main-list-item>div.cbs-main-list-item-section-header>.cbs-main-list-item-section-header-header>span
			{
				color:#<?php echo $this->data['color'][3]; ?>;
			}
<?php
		}
		if(isset($this->data['color'][4]))
		{	
?>
			
			<?php echo $this->data['mainCSSClass']; ?> .cbs-form .cbs-form-summary .cbs-form-info,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-package-list>li>.cbs-package-service-list>li,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-main-list>li.cbs-main-list-item>div.cbs-main-list-item-section-header>.cbs-main-list-item-section-header-subheader,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-service-list>li>div.cbs-service-name .cbs-more-content,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar .cbs-calendar-data a,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-form textarea,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-form input[type="text"]
			{
				color:#<?php echo $this->data['color'][4]; ?>;
			}
<?php
		}
		if(isset($this->data['color'][5]))
		{	
?>
			<?php echo $this->data['mainCSSClass']; ?> .cbs-form label,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-vehicle-list>li,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-booking-summary>li>span,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-package-list>li>.cbs-package-duration,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-service-list>li>div.cbs-service-price,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-service-list>li>div.cbs-service-duration,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar .cbs-calendar-subheader .cbs-calendar-subheader-day-name,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar .cbs-calendar-data,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar .cbs-calendar-subheader .cbs-calendar-subheader-day-number.cbs-state-disable
			{
				color:#<?php echo $this->data['color'][5]; ?>;
			}	
<?php
		}
		if(isset($this->data['color'][6]))
		{	
?>
			<?php echo $this->data['mainCSSClass']; ?> .cbs-vehicle-list>li,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-package-list>li,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-service-list>li,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-booking-summary>li,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-form .cbs-form-field,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-package-list>li>.cbs-package-duration,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar tr>th,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar tr>td,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar .cbs-calendar-subheader .cbs-calendar-subheader-day-number,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar .cbs-calendar-data a,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar-header .cbs-calendar-header-arrow-left,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar-header .cbs-calendar-header-arrow-right,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-to-tab.ui-tabs .ui-tabs-nav li,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-coupon-code input[name="coupon_code"]
			{
				border-color:#<?php echo $this->data['color'][6]; ?>;
			}
<?php
		}
		if(isset($this->data['color'][7]))
		{	
?>
			<?php echo $this->data['mainCSSClass']; ?> .cbs-main-list>li.cbs-main-list-item.cbs-state-disable>div.cbs-main-list-item-section-header>.cbs-main-list-item-section-header-step
			{
				background-color:#<?php echo $this->data['color'][7]; ?>;
			}
<?php
		}
		if(isset($this->data['color'][8]))
		{	
?>
			<?php echo $this->data['mainCSSClass']; ?> .cbs-main-list>li.cbs-main-list-item.cbs-state-disable>div.cbs-main-list-item-section-header>.cbs-main-list-item-section-header-step>span
			{
				color:#<?php echo $this->data['color'][8]; ?>;
			}
<?php
		}
		if(isset($this->data['color'][9]))
		{	
?>
			<?php echo $this->data['mainCSSClass']; ?> .cbs-main-list>li.cbs-main-list-item.cbs-state-disable>div.cbs-main-list-item-section-header>.cbs-main-list-item-section-header-header>span,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-main-list>li.cbs-main-list-item.cbs-state-disable>div.cbs-main-list-item-section-header>.cbs-main-list-item-section-header-subheader>span
			{
				color:#<?php echo $this->data['color'][9]; ?>;
			}
<?php
		}
		if(isset($this->data['color'][10]))
		{	
?>
			<?php echo $this->data['mainCSSClass']; ?> .cbs-meta-icon,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-vehicle-icon,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar-header .cbs-calendar-header-arrow-left,
			<?php echo $this->data['mainCSSClass']; ?> .cbs-calendar-header .cbs-calendar-header-arrow-right
			{
				color:#<?php echo $this->data['color'][10]; ?>;
			}
<?php
		}