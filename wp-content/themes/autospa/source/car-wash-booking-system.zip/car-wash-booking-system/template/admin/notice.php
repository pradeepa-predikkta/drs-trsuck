		<div class="to-notice to-notice-<?php echo $this->data['type']; ?> to-clear-fix">
			<span></span>
			<h4><?php echo $this->data['title']; ?></h4>
			<h6><?php echo $this->data['subtitle']; ?></h6>
		</div>