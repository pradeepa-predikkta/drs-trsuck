<?php
if(array_key_exists('paymentForm',$this->data['other']))
{
?>
		<tr>
			<td>
				<?php echo $this->data['other']['paymentForm']; ?>
			</td>
		</tr>
<?php
}
?>